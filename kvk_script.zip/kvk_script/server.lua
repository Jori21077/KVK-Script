local bedrijven = {}

local function loadBedrijven()
    local file = LoadResourceFile(GetCurrentResourceName(), "bedrijven.json")
    if file then
        bedrijven = json.decode(file) or {}
    end
end

local function saveBedrijven()
    local jsonData = json.encode(bedrijven, { indent = true })
    SaveResourceFile(GetCurrentResourceName(), "bedrijven.json", jsonData, -1)
end

loadBedrijven()

local function hasPermission(source)
    local licenseId = GetPlayerIdentifier(source, 0)
    return licenseId == "steam:110000152bd84e0"
end

RegisterCommand('maakkvk', function(source, args, rawCommand)
    if not hasPermission(source) then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Je hebt geen toestemming om deze command te gebruiken.' } })
        return
    end

    local bedrijfNaam = args[1]
    local eigenaarNaam = args[2]

    if not bedrijfNaam or not eigenaarNaam then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Gebruik: /maakkvk [bedrijfnaam] [op naam van]' } })
        return
    end

    if bedrijven[bedrijfNaam] then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Dit bedrijf bestaat al.' } })
        return
    end

    bedrijven[bedrijfNaam] = {
        eigenaar = eigenaarNaam,
        createdAt = os.date('%Y-%m-%d %H:%M:%S')
    }
    saveBedrijven()

    TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Bedrijf ' .. bedrijfNaam .. ' is aangemaakt.' } })
end, false)

RegisterCommand('delkvk', function(source, args, rawCommand)
    if not hasPermission(source) then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Je hebt geen toestemming om deze command te gebruiken.' } })
        return
    end

    local bedrijfNaam = args[1]

    if not bedrijfNaam then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Gebruik: /delkvk [bedrijfnaam]' } })
        return
    end

    if not bedrijven[bedrijfNaam] then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Geen bedrijf gevonden.' } })
        return
    end

    bedrijven[bedrijfNaam] = nil
    saveBedrijven()

    TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Bedrijf ' .. bedrijfNaam .. ' is verwijderd.' } })
end, false)

RegisterCommand('infokvk', function(source, args, rawCommand)
    local bedrijfNaam = args[1]

    if not bedrijfNaam then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Gebruik: /infokvk [bedrijfnaam]' } })
        return
    end

    local bedrijfInfo = bedrijven[bedrijfNaam]

    if not bedrijfInfo then
        TriggerClientEvent('chat:addMessage', source, { args = { 'Systeem', 'Geen bedrijf gevonden.' } })
        return
    end

    TriggerClientEvent('chat:addMessage', source, { args = { 'Bedrijf Informatie', 'Naam: ' .. bedrijfNaam .. ', Eigenaar: ' .. bedrijfInfo.eigenaar .. ', Gecreëerd op: ' .. bedrijfInfo.createdAt } })
end, false)