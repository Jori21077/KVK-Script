Om deze script te gebruiken in game en je kent weinig van developen volg deze instructies!

1: Ga naar de server.lua
2: Verander het steam id op lijn 19 naar je eigen steamid
3: Ga dan naar de bedrijven.json en haal alles uit dat bestand niet het bestand zelf alleen de text IN het bestand
4: Restart je server of de script
5: Gebruik deze in game voor een kvk te maken /maakkvk [bedrijf_naam] [Eigenaar]
Important! Voor de bedrijf naam en eigenaar mag je geen spaties zetten alleen een spatie na elk textje dus doen hoe ik het heb gezet
6: Je bent er helemaal klaar voor! Bedankt dat je mijn open source script hebt gebruikt.

Commands:

/maakkvk [bedrijf_naam] [Eigenaar]
/delkvk [bedrijf_naam]
/infokvk [bedrijf_naam]