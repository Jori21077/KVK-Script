Citizen.CreateThread(function()
   
    AddTextEntry('maakkvk', '/maakkvk [bedrijfnaam] [op naam van]')
    AddTextEntry('delkvk', '/delkvk [bedrijfnaam]')
    AddTextEntry('infokvk', '/infokvk [bedrijfnaam]')
end)