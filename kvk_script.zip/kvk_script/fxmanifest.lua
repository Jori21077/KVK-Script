fx_version 'cerulean'
game 'gta5'

author 'ItsDevJori'
description 'KVK Bedrijven Systeem'
version '1.0.0'

-- Client scripts
client_scripts {
    'client.lua'  
}

-- Server scripts
server_scripts {
    'server.lua'  
}
